int read_something(void); 
int do_something(int); 
void write_something(const char*);

int some_global_variable;
static int some_local_variable;

main() {
	int some_stack_variable;
	some_stack_variable = read_something(); 
	some_global_variable = do_something(some_stack_variable);
	write_something("I am done"); 
}
