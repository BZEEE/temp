#include<stdio.h>
extern int some_global_variable;

int read_something(void) {
	int res;
	scanf("%d",&res);
	return res;
}

int do_something(int var){
	return var + var; 
}

void write_something(const char* str){
	printf("%s: %d\n",str,some_global_variable);
}
